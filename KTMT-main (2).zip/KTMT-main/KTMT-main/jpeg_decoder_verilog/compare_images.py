from PIL import Image
import numpy as np

def read_ppm(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    
    # Simple PPM P3 parser
    data = []
    width = 0
    height = 0
    max_val = 255
    
    header_done = False
    
    clean_lines = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        clean_lines.extend(line.split())
        
    if clean_lines[0] != 'P3':
        print("Not a P3 PPM file")
        return None

    width = int(clean_lines[1])
    height = int(clean_lines[2])
    max_val = int(clean_lines[3])
    
    pixel_data = [int(x) for x in clean_lines[4:]]
    
    # Fix for Partial Image: Pad with zeros
    expected_len = width * height * 3
    if len(pixel_data) < expected_len:
         print(f"Warning: Image incomplete. Got {len(pixel_data)} values, expected {expected_len}. Padding with zeros.")
         pixel_data.extend([0] * (expected_len - len(pixel_data)))
    elif len(pixel_data) > expected_len:
         pixel_data = pixel_data[:expected_len]

    img = np.array(pixel_data, dtype=np.uint8).reshape((height, width, 3))
    return img

def compare():
    # Load input JPEG
    try:
        input_img = Image.open('data/20260104.124356-avatar-cute-3_resized.jpeg').convert('RGB')
        input_arr = np.array(input_img)
        print(f"Input Image: {input_arr.shape}")
    except Exception as e:
        print(f"Error loading input image: {e}")
        return

    # Load output PPM
    import sys
    ppm_file = 'sim/output.ppm'
    if len(sys.argv) > 1:
        ppm_file = sys.argv[1]
        
    try:
        output_arr = read_ppm(ppm_file)
        if output_arr is None:
            return
        print(f"Output Image: {output_arr.shape}")
    except Exception as e:
        print(f"Error loading output image: {e}")
        return
        
    if input_arr.shape != output_arr.shape:
        print("Dimensions mismatch!")
        return

    # Compare
    diff = np.abs(input_arr.astype(int) - output_arr.astype(int))
    print(f"Mean Difference: {np.mean(diff)}")
    print(f"Max Difference: {np.max(diff)}")
    
    # Save difference image
    diff_img = Image.fromarray(diff.astype(np.uint8))
    diff_img.save('sim/diff.png')
    print("Saved diff.png")
    
    # Save output as PNG for easy viewing
    Image.fromarray(output_arr).save('sim/output_converted.png')
    print("Saved output_converted.png")

if __name__ == "__main__":
    compare()
