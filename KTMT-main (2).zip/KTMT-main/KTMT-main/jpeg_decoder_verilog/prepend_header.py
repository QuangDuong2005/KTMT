import sys

def prepend_header(input_file, output_file, width, height):
    try:
        # Read content
        with open(input_file, 'r', encoding='ascii', errors='ignore') as f:
            content = f.read()
        
        # Write header + content
        with open(output_file, 'w', encoding='ascii') as f:
            f.write(f"P3\n{width} {height}\n255\n")
            f.write(content)
            
        print(f"Successfully created {output_file}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        # Default usage for this task
        prepend_header('sim/output.ppm', 'sim/output_fixed.ppm', 80, 80)
    else:
        prepend_header(sys.argv[1], sys.argv[2], 80, 80)
